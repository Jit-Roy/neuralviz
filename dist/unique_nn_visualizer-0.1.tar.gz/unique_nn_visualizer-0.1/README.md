# nn_visualizer

A Python module for visualizing neural network training in real-time.

## Installation

```bash
pip install git+https://github.com/yourusername/nn_visualizer.git

